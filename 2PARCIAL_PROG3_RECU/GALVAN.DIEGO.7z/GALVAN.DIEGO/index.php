<?php
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;
use \Firebase\JWT\JWT;

require_once './vendor/autoload.php';
require_once './clases/AccesoDatos.php';
require_once './clases/Auto.php';
require_once './clases/Usuario.php';
require_once './clases/MW.php';

$config['displayErrorDetails'] = true;
$config['addContentLengthHeader'] = false;

$app = new \Slim\App(["settings" => $config]);

$app->post('/usuarios', \Usuario::class . '::Alta')->add(\MW::class. "::ExisteAlta")
->add(\MW::class. "::Vacios")->add(\MW::class. "::Seteados");

$app->get('[/]', \Usuario::class . '::Lista');

$app->post('[/]', \Auto::class . '::Alta')->add(\MW::class. "::AutoAlta");

$app->get('/autos', \Auto::class . '::Lista');

$app->group('/login', function () 
{    
    $this->post('/', \Usuario::class . '::CrearJWT');
    
    $this->get('/', \Usuario::class . '::VerificarJWT');
})->add(\MW::class. "::Existe")->add(\MW::class. "::Vacios")->add(\MW::class. "::Seteados");

$app->delete('[/]', \Auto::class . '::Borrar')->add(\MW::class. "::Propietario")->add(\MW::class. "::VerificarToken");

$app->put('[/]', \Auto::class . '::Modificar')->add(\MW::class. "::VerificarToken");

$app->run();