<?php
require_once 'AccesoDatos.php';
require_once 'AutentificadorJWT.php';

class Auto
{
    public static function Alta($request,$response)
    {
        $datos=$request->getParsedBody(); 
        $json=json_decode($datos["json"]);
        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
        $consulta = $objetoAccesoDato->RetornarConsulta("INSERT into  
        autos (color, marca, precio, modelo)
        values(:color, :marca, :precio, :modelo)");

        $consulta->bindValue(':color', $json->color, PDO::PARAM_STR);
        $consulta->bindValue(':marca', $json->marca, PDO::PARAM_STR);
        $consulta->bindValue(':precio', $json->precio, PDO::PARAM_INT);
        $consulta->bindValue(':modelo', $json->modelo, PDO::PARAM_STR);

        $retornojson=new StdClass();
        $consulta->execute();   
        if($consulta->rowCount()>0) //SI EXISTE EL CORREO EN LA BASE DE DATOS, DEVUELVE 1 FILA
        {
            $retornojson->exito=true; $retornojson->mensaje="Auto dado de alta!";
            $retorno=$response->withJson($retornojson,200);
        }else
        {
            $retornojson->exito=false; $retornojson->mensaje="Error. No se dio de alta";
            $retorno=$response->withJson($retornojson,418);
        }
        return $retorno;
    }

    public static function Lista($request,$response)
    {
        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
        $consulta = $objetoAccesoDato->RetornarConsulta("SELECT * FROM autos");        
        $consulta->execute();
        if($consulta->rowCount()>0) //SI EXISTE EL CORREO EN LA BASE DE DATOS, DEVUELVE 1 FILA
        {
        $obj=$consulta->FetchAll();
        
        $tabla='<table border=`5`><tr><td>ID</td><td>COLOR</td><td>MARCA</td>
                <td>MODELO</td><td>PRECIO</td></tr>';
        for ($i=0; $i <count($obj) ; $i++) 
        { 
        $tabla.='<tr><td>'.$obj[$i]["id"].'</td><td>'.$obj[$i]["color"].'</td><td>'.$obj[$i]["marca"].'</td>
        <td>'.$obj[$i]["modelo"].'</td><td>'.$obj[$i]["precio"].'</td></tr>';
        }
        $tabla.="</table>";
        
        $respuesta=new StdClass();
        $respuesta->exito=true; $respuesta->mensaje="La tabla se cargo correctamente";
        $respuesta->tabla=$tabla;   
        $retorno=$response->withJson($respuesta,200);
        return $retorno;
        }
        else
        {
            $respuesta->exito=false; $respuesta->mensaje="Error. No puedo mostrar la tabla";
            $retorno=$response->withJson($respuesta,424);
        }
        return $retorno;
    }

    public static function Borrar($request,$response)
    {
        $datos=$request->getParsedBody(); 
        $objJSON=json_decode($datos["json"]);
        $id=$objJSON->id;
        $datatoken=AutentificadorJWT::ObtenerData($objJSON->token);
        $respuesta=new StdClass();
       
        if($datatoken->perfil=="propietario")
        {
            $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
        
            $consulta = $objetoAccesoDato->RetornarConsulta("DELETE FROM autos WHERE id=:id"); 
            $consulta->bindValue(':id', $id, PDO::PARAM_INT); 
            $consulta->execute();
            if($consulta->rowCount()>0)
            {
                $respuesta->exito=true; $respuesta->mensaje="Se elimino correctamente";
                $response=$response->withJson($respuesta,200);
                return $response;
            }
            else
            {
                $respuesta->exito=false; $respuesta->mensaje="No se elimino";
                $response=$response->withJson($respuesta,418);
                return $response;
            }
        }
        else
        {
            $respuesta->exito=false; $respuesta->mensaje="No tiene permisos ".$datatoken->nombre;
            $response=$response->withJson($respuesta,418);
            return $response;
        }
    }

    public static function Modificar($request,$response)
    {
        $datos=$request->getParsedBody(); 
        $objJSON=json_decode($datos["json"]);
        
        $datatoken=AutentificadorJWT::ObtenerData($objJSON->token);
        $respuesta=new StdClass();
       
        if($datatoken->perfil=="propietario" || $datatoken->perfil=="encargado")
        {
            $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
            $consulta = $objetoAccesoDato->RetornarConsulta("UPDATE autos SET `color`=:color,`modelo`=:modelo,
                                                            `precio`=:precio, `marca`=:marca WHERE id=:id"); 
            $consulta->bindValue(':id', $objJSON->id, PDO::PARAM_INT); 
            $consulta->bindValue(':color', $objJSON->color, PDO::PARAM_STR);
            $consulta->bindValue(':marca', $objJSON->marca, PDO::PARAM_STR);
            $consulta->bindValue(':precio', $objJSON->precio, PDO::PARAM_INT);
            $consulta->bindValue(':modelo', $objJSON->modelo, PDO::PARAM_STR);
            
            $consulta->execute();
            if($consulta->rowCount()>0)
            {
                $respuesta->exito=true; $respuesta->mensaje="Se modifico correctamente";
                $response=$response->withJson($respuesta,200);
                return $response;
            }
            else
            {
                $respuesta->exito=false; $respuesta->mensaje="No se modifico";
                $response=$response->withJson($respuesta,418);
                return $response;
            }
        }
        else
        {
            $respuesta->exito=false; $respuesta->mensaje="No tiene permisos ".$datatoken->nombre;
            $response=$response->withJson($respuesta,418);
            return $response;
        }
    }
}
