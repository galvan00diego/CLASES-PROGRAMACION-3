<?php  
namespace App\Models;
 
class cd extends \Illuminate\Database\Eloquent\Model {  
  
}
