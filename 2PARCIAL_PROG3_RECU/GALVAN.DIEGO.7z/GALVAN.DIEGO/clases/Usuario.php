<?php

require_once 'AccesoDatos.php';
require_once 'AutentificadorJWT.php';

class Usuario
{
    public static function Alta($request,$response)
    {
        date_default_timezone_set("America/Argentina/Buenos_Aires");

        $datos=$request->getParsedBody(); 
        $json=json_decode($datos["json"]);
        
        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();

        /********************************************************** */
        $archivos = $request->getUploadedFiles();
        $destino="./fotos/";
        $nombreAnterior = $archivos['foto']->getClientFilename();    
        $extension = explode(".", $nombreAnterior);
        $destino .= $json->correo. "." .date("h-i-s_j-m-y"). "." . $extension[1];
        $archivos['foto']->moveTo($destino);
        $json->foto=$json->correo. "." .date("h-i-s_j-m-y"). "." . $extension[1]; //NOMBRE FOTO EN BD
        /******************************************************************** */
        
        $consulta =$objetoAccesoDato->RetornarConsulta("INSERT INTO usuarios (correo, clave, nombre,
                                                        apellido, perfil, foto)
                                                    VALUES(:correo, :clave, :nombre,
                                                    :apellido, :perfil, :foto)");
       
        
        $consulta->bindValue(':nombre', $json->nombre, PDO::PARAM_STR);
        $consulta->bindValue(':apellido', $json->apellido, PDO::PARAM_STR);
        $consulta->bindValue(':clave', $json->clave, PDO::PARAM_STR);
        $consulta->bindValue(':foto', $json->foto, PDO::PARAM_STR);
        $consulta->bindValue(':perfil', $json->perfil, PDO::PARAM_STR);
        $consulta->bindValue(':correo', $json->correo, PDO::PARAM_STR);
        $retornojson=new StdClass();
        $consulta->execute();   
        if($consulta->rowCount()>0) //SI EXISTE EL CORREO EN LA BASE DE DATOS, DEVUELVE 1 FILA
        {
            $retornojson->exito=true; $retornojson->mensaje="Usuario dado de alta!";
            $retorno=$response->withJson($retornojson,200);
        }else
        {
            $retornojson->exito=false; $retornojson->mensaje="Error. No se dio de alta";
            $retorno=$response->withJson($retornojson,418);
        }
        return $retorno;
    }

    public static function Lista($request,$response)
    {
        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
        $consulta = $objetoAccesoDato->RetornarConsulta("SELECT * FROM usuarios");        
        $consulta->execute();
        if($consulta->rowCount()>0) //SI EXISTE EL CORREO EN LA BASE DE DATOS, DEVUELVE 1 FILA
        {
        $obj=$consulta->FetchAll();
        
        $tabla="<table border='5'><tr><td>ID</td><td>CORREO</td><td>NOMBRE</td><td>APELLIDO</td><td>PERFIL</td><td>FOTO</td></tr>";
        for ($i=0; $i <count($obj) ; $i++) 
        { 
        $tabla.='<tr><td>'.$obj[$i]["id"].'</td><td>'.$obj[$i]["correo"].'</td><td>'.$obj[$i]["nombre"].'</td><td>'.$obj[$i]["apellido"].'</td><td>'.$obj[$i]["perfil"]."</td><td><img src='./fotos/".$obj[$i]["foto"]."' height='100px' width='100px'></td></tr>";
        }
        $tabla.='</table>';
        $respuesta=new StdClass();
        $respuesta->exito=true; $respuesta->mensaje="La tabla se cargo correctamente";
        $respuesta->tabla=$tabla;   
        $retorno=$response->withJson($respuesta,200);
        return $retorno;
        }
        else
        {
            $respuesta->exito=false; $respuesta->mensaje="Error. No puedo mostrar la tabla";
            $retorno=$response->withJson($respuesta,424);
        }
        return $retorno;

    }

    public static function CrearJWT($request, $response)
    {
        $datos = $request->getParsedBody();
        $jsonDatos = $datos['json'];
        $usuario = json_decode($jsonDatos);
        $json = new stdClass();
        
        $usuarioCompleto = Usuario::ExisteUsuario($usuario);

        if($usuarioCompleto!=null)
        {
            $usuarioCompletophp = new stdClass();
            $usuarioCompletophp->correo = $usuarioCompleto[0]["correo"];
            $usuarioCompletophp->clave = $usuarioCompleto[0]["clave"];
            $usuarioCompletophp->nombre = $usuarioCompleto[0]["nombre"];
            $usuarioCompletophp->apellido = $usuarioCompleto[0]["apellido"];
            $usuarioCompletophp->perfil = $usuarioCompleto[0]["perfil"];
            $usuarioCompletophp->foto = $usuarioCompleto[0]["foto"];

            $jwt = AutentificadorJWT::CrearToken($usuarioCompletophp);

            if($jwt != "")
                {
                    $json->exito=true; 
                    $json->jwt = $jwt;
                    $newResponse = $response->withJson($json,200);
                }
            }
        
        else
        {
            $json->exito=false; 
            $json->jwt = null;
            $newResponse = $response->withJson($json,403);
        }
        

        return $newResponse;
       
    }

    public static function ExisteUsuario($usuario)
    {
        
        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
        $consulta = $objetoAccesoDato->RetornarConsulta("SELECT * FROM usuarios 
                                                        WHERE correo=:correo AND clave=:clave");

        $consulta->bindValue(":correo",$usuario->correo,PDO::PARAM_STR);
        $consulta->bindValue(":clave",$usuario->clave,PDO::PARAM_STR);

        $consulta->execute();
        
        $datos = $consulta->fetchAll();

        return $datos;     
    }

    public static function VerificarJWT($request, $response)
    {
        $headers = getallheaders();
        $json = new stdClass();

        if(AutentificadorJWT::VerificarToken($headers["jwt"]))
        {
            $json->exito=true; 
            $json->mensaje = "Usuario validado.";
            $newResponse = $response->withJson($json,200);
        }
        else
        {
            $json->exito=false; 
            $json->mensaje = "Usuario no validado.";
            $newResponse = $response->withJson($json,403);
        }

        return $newResponse;
    }


}