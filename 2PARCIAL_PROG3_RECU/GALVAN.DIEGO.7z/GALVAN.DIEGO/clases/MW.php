<?php
use Slim\Http\Message;

require_once 'AccesoDatos.php';
require_once 'AutentificadorJWT.php';

class MW
{
    public function VerificarToken($request, $response, $next)
    {
        $datos = $request->getParsedBody();
        $objetoJSON = json_decode($datos['json']);
        $jwt=$objetoJSON->token;

        if(AutentificadorJWT::VerificarToken($jwt))
        {
            
            $newResponse = $next($request, $response);
        }
        else
        {
            $newResponse = $response->withJson(["Mensaje" => "Error, token invalido."], 403);
        }

        return $newResponse;
    }

    static function Propietario($request,$response,$next)
    {
        $datos = $request->getParsedBody();
        $objetoJSON = json_decode($datos['json']);
        $jwt=$objetoJSON->token;
        $obj=AutentificadorJWT::ObtenerData($jwt);
        $respuesta=new StdClass();
        if($obj->perfil=="propietario")
        {
            $respuesta->propietario=true; $respuesta->mensaje="Es propietario";
            echo $response->withJson($respuesta,200);
            $response=$next($request,$response);
            return $response;
        }
        else
        {
            $respuesta->propietario=false; $respuesta->mensaje="No es propietario ".$obj->nombre;
            $retorno=$response->withJson($respuesta,409);
            
            return $retorno;
        }
    }

    function Encargado($request,$response,$next)
    {
        $datos = $request->getParsedBody();
        $objetoJSON = json_decode($datos['json']);
        $jwt=$objetoJSON->token;
        $obj=AutentificadorJWT::ObtenerData($jwt);
        $respuesta=new StdClass();
        if($obj->perfil=="encargado")
        {
            //$respuesta->encargado=true; $respuesta->mensaje="Es encargado";
            //$retorno=$response->withJson($respuesta,200);
            $response=$next($request,$response);
            return $response;
        }
        else
        {
            $respuesta->encargado=false; $respuesta->mensaje="No es encargado ".$obj->nombre;
            $retorno=$response->withJson($respuesta,409);
            
            return $retorno;
        }
    }

    /*1.- (método de instancia) Verifique que estén seteados el correo y la clave.
    Si no existe alguno de los dos (o los dos) retorne un JSON con el mensaje de error
    correspondiente (y status 403).
    Si existen, pasar al siguiente Middleware que verifique que:*/

    public function Seteados($request,$response,$next)
    {
        $datos = $request->getParsedBody();
        $objetoJSON = json_decode($datos['json']);
        $respuesta=new StdClass();
        if(isset($objetoJSON->correo) || isset($objetoJSON->clave))
        {
            if(isset($objetoJSON->correo))
            {
                if(isset($objetoJSON->clave))
                {
                    $response=$next($request,$response);
                    return $response;
                }
                else
                {
                    $respuesta->mensaje="Ingrese su clave!!";
                    $retorno=$response->withJson($respuesta,409);
                    return $retorno;
                }
            }
            else
            {
                $respuesta->mensaje="Ingrese el correo!!";
                $retorno=$response->withJson($respuesta,409);
                return $retorno;
            }
        }
        else
            {
                $respuesta->mensaje="Ingrese el correo y clave!!";
                $retorno=$response->withJson($respuesta,409);
                return $retorno;
            }
    }

    public static function Vacios($request,$response,$next)
    {
        $datos = $request->getParsedBody();
        $objetoJSON = json_decode($datos['json']);
        $respuesta=new StdClass();

        if(strlen($objetoJSON->correo)>0 || strlen($objetoJSON->clave)>0)
        {
            if(strlen($objetoJSON->correo)>0)
            {
                if(strlen($objetoJSON->clave)>0)
                {
                    $response=$next($request,$response);
                    return $response;
                }
                else
                {
                    $respuesta->mensaje="La clave esta vacia. Completar!!";
                    $retorno=$response->withJson($respuesta,409);
                    return $retorno;
                }
            }
            else
            {
                $respuesta->mensaje="El correo esta vacio. Completar!!";
                $retorno=$response->withJson($respuesta,409);
                return $retorno;
            }
        }
        else
        {
            $respuesta->mensaje="Debe completar ambos campos. Completar!!";
            $retorno=$response->withJson($respuesta,409);
            return $retorno;
        }

    }

    public function Existe($request,$response,$next)
    {
        $datos = $request->getParsedBody();
        $usuario = json_decode($datos['json']);
        $respuesta=new StdClass();

        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
        $consulta = $objetoAccesoDato->RetornarConsulta("SELECT * FROM usuarios 
                                                        WHERE correo=:correo AND clave=:clave");

        $consulta->bindValue(":correo",$usuario->correo,PDO::PARAM_STR);
        $consulta->bindValue(":clave",$usuario->clave,PDO::PARAM_STR);

        $consulta->execute();

        if($consulta->rowCount()>0)
        {
            $response=$next($request,$response);
            return $response;
        }
        else
        {
            $respuesta->mensaje="El usuario no existe. Debe registrarse";
            $retorno=$response->withJson($respuesta,403);
            return $retorno;
        }
    }

    public static function ExisteAlta($request,$response,$next)
    {
        $datos = $request->getParsedBody();
        $usuario = json_decode($datos['json']);
        $respuesta=new StdClass();

        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
        $consulta = $objetoAccesoDato->RetornarConsulta("SELECT * FROM usuarios 
                                                        WHERE correo=:correo");

        $consulta->bindValue(":correo",$usuario->correo,PDO::PARAM_STR);
        $consulta->execute();
        if($consulta->rowCount()>0)
        {
            $respuesta->mensaje="El correo ingresado esta registrado!!";
            $retorno=$response->withJson($respuesta,403);
            return $retorno;
        }
        else
        {
            $response=$next($request,$response);
            return $response;
           
        }
    }

    public function AutoAlta($request,$response,$next)
    {
        $datos = $request->getParsedBody();
        $auto = json_decode($datos['json']);
        $respuesta=new StdClass();

        if($auto->precio>=50000 && $auto->precio<=600000 || $auto->color!="azul")
        {
            if($auto->color!="azul")
            {
                if($auto->precio>=50000 && $auto->precio<=600000)
                {
                    $response=$next($request,$response);
                    return $response;
                }
                else
                {
                    $respuesta->mensaje="El auto debe tener un valor entre 50000 y 600000";
                    $retorno=$response->withJson($respuesta,403);
                    return $retorno;
                }
            }
            else
            {
                $respuesta->mensaje="El auto no puede ser de color azul";
                $retorno=$response->withJson($respuesta,403);
                return $retorno;
            }
        
            
        }
        else
        {
            $respuesta->mensaje="El auto debe tener un valor entre 50000 y 600000. No puede ser de color azul";
            $retorno=$response->withJson($respuesta,403);
            return $retorno;
        }
    }
}